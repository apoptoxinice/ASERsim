#!/bin/bash
make > 1.txt 2>&1
