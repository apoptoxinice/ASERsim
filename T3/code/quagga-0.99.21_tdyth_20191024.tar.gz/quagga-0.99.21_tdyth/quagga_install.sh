#!/bin/bash
./configure --enable-vtysh --enable-zebra --enable-bgpd --enable-user=root --enable-group=root -enable-vty-group=root
#make clean
#make
#make install
